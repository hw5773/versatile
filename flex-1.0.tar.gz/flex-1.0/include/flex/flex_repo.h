#ifndef __FLEX_REPO__
#define __FLEX_REPO__

struct repo
{

}

int init_repo(void);
int insert_content(unsigned char *fname);

#endif /* __FLEX_REPO__ */
