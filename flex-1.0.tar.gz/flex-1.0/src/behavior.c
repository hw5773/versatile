#include <flex/flex.h>

int get(flexid_t *id, char *resp, int *len)
{
  return SUCCESS;
}

int put(flexid_t *id, char *resp, int *len)
{
  return SUCCESS;
}
