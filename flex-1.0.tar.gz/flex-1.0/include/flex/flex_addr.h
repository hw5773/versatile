#ifndef __FLEX_ADDR__
#define __FLEX_ADDR__

#define MAX_ADDRESS_LENGTH  32

// AT: Address Type
#define AT_MAC        0

#define AT_MAC_LEN    6

#endif /* __FLEX_ADDR__ */
