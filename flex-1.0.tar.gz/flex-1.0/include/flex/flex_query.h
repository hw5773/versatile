#ifndef __FLEX_QUERY__
#define __FLEX_QUERY__

#include <flex/flex_types.h>
#include <flex/flex_const.h>

struct query_list
{

};

struct reply_list
{

};

struct reply_list *query(struct query_list *);

#endif /* __FLEX_CONTROL__ */
